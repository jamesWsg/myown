#!/bin/bash

##########################################
# $1: number of replicas
# $2: expected dir
# $3: segment interval
#########################################

DEBUG_LOG="./test_result/debug.log"

echo -e "`date +'%Y-%m-%d %H:%M:%N'`\t------------------ get  --------------------\n" | tee -a $DEBUG_LOG
echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tStart taking camera...\n" | tee -a $DEBUG_LOG
./get.sh rtsp://admin:admin12345@172.17.59.223:554 rtmp://127.0.0.1:1554/live/cam

echo -e "`date +'%Y-%m-%d %H:%M:%N'`\t------------------ push --------------------\n" | tee -a $DEBUG_LOG
echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tStart pushing to storage...\n" | tee -a $DEBUG_LOG
./push.sh rtmp://127.0.0.1:1554/live/cam 1 $1 

echo -e "`date +'%Y-%m-%d %H:%M:%N'`\t------------------ record ------------------\n" | tee -a $DEBUG_LOG
echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tStart recording to cluster...\n" | tee -a $DEBUG_LOG
./record.sh 1 $1 $2 $3
