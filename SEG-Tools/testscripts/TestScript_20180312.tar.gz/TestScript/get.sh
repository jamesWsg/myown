#!/bin/bash

DEBUG_LOG="./test_result/debug.log"

usage(){
 echo "Usage: `basename $0` srcRtsp dstRtmp"
}

#从原始摄像头获取视频流到本地
getStream(){
/usr/bin/ffmpeg -loglevel quiet -f rtsp -rtsp_transport tcp -i $1 -vcodec copy -an -f flv $2 &
echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tCommand line is: /usr/bin/ffmpeg -loglevel quiet -f rtsp -rtsp_transport tcp -i $1 -vcodec copy -an -f flv $2  PID: $!\n" | tee -a $DEBUG_LOG
}


if [ $# -lt 2 ];then
 usage
 exit 1
fi


srcRtsp=$1
dstRtmp=$2
 {
  getStream $srcRtsp $dstRtmp
 } 
exit 0;
