#!/bin/bash

DEBUG_LOG="./test_result/debug.log"

usage(){
 echo "Usage: `basename $0` srcRtmp startNum stopNum"
}


#从本地推流到流媒体服务器
pushStream(){
 /usr/bin/ffmpeg -loglevel quiet -i $1 -vcodec copy -an -f flv rtmp://127.0.0.1:1554/live/cam$2 &
 echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tCommand line is: /usr/bin/ffmpeg -loglevel quiet -i $1 -vcodec copy -an -f flv rtmp://127.0.0.1:1554/live/cam$2  PID: $!\n" | tee -a $DEBUG_LOG

}


if [ $# -lt 3 ];then
 usage
 exit 1
fi


srcRtmp=$1
numStartRtmp=$2
numStopRtmp=$3

for((i=$numStartRtmp;i<=$numStopRtmp;i++))
do
if [ `expr $i % 100` = 0 ];then
  sleep 1
 fi
 echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tStart pushing process $i...\n" | tee -a $DEBUG_LOG

 {
  pushStream $srcRtmp $i
 } 

done
