#!/bin/bash

#Initializing
usage(){
	echo -e "Usage: `basename $0` NAS_EC_Folder Segment_interval Number_of_repl Test_duration\n"
	echo -e "  Example: run_all.sh /var/share/Default/doc/NAS_EC/32/ 1800 100 1860\n"
}

if [ $# -lt 4 ];then
	usage
	exit 1
fi

NVME_DEV="/dev/nvme0n1"
TEST_RESULT="./test_result"
NVME_USAGE_LOG="./test_result/nvme_use.log"
RADOS_USAGE_LOG="./test_result/rados_df.log"
DEBUG_LOG="./test_result/debug.log"
#BASE_PATH="/var/share/Default/doc/NAS_EC/32/"
BASE_PATH=$1
CURRENT_DATE=`date +%Y_%m_%d`
EXPECT_DIR=${BASE_PATH}${CURRENT_DATE}
SEGMENT_INTERVAL=$2
NUM_OF_REPL=$3
TEST_DURATION=$4

#Tear up
# Create test result folder
if [ ! -d $TEST_RESULT ];then
	mkdir -p $TEST_RESULT
fi
# Create folder for stream data
if [ ! -d $EXPECT_DIR ];then
	mkdir -p $EXPECT_DIR
else 
	#May have rubbish test data, remove it.
	rm -rf $EXPECT_DIR	
	mkdir -p $EXPECT_DIR
fi


####################################################################

#Main 
echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tStart test...\n" | tee $DEBUG_LOG

echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tSave initial nvme usage...\n" | tee -a $DEBUG_LOG
echo -e "`date +'%Y-%m-%d %H:%M:%N'`  ------------pretest---------\n" > $NVME_USAGE_LOG
/root/smartctl -A $NVME_DEV >> $NVME_USAGE_LOG 

echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tSave initial rados usage...\n" | tee -a  $DEBUG_LOG
echo -e "`date +'%Y-%m-%d %H:%M:%N'`  ------------pretest---------\n" > $RADOS_USAGE_LOG
rados df >> $RADOS_USAGE_LOG

echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tStart monitoring...\n" | tee -a  $DEBUG_LOG
./monitor.sh &

echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tStart capturing data...\n" | tee -a  $DEBUG_LOG
./run.sh $NUM_OF_REPL $EXPECT_DIR $SEGMENT_INTERVAL & 

sleep $TEST_DURATION

#./ngnix_restart.sh & 
/etc/init.d/nginx restart

echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tSave final nvme usage...\n" | tee -a  $DEBUG_LOG
echo -e "\n\n" >> $NVME_USAGE_LOG
echo -e "`date +'%Y-%m-%d %H:%M:%N'`  ------------postest---------\n" >> $NVME_USAGE_LOG
/root/smartctl -A $NVME_DEV >> $NVME_USAGE_LOG

echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tSave final rados usage...\n" | tee -a  $DEBUG_LOG
echo -e "\n\n" >> $RADOS_USAGE_LOG
echo -e "`date +'%Y-%m-%d %H:%M:%N'`  ------------postest---------\n" >> $RADOS_USAGE_LOG
rados df  >> $RADOS_USAGE_LOG

# Summary
./summary.sh $EXPECT_DIR

echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tStop testing...\n" | tee -a  $DEBUG_LOG
