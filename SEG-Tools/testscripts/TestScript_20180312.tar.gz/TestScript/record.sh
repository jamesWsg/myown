#!/bin/bash

######################################
# $1: constant, 1
# $2: number of replicas
# $3: expect dir
# $4: segment interval
######################################

DEBUG_LOG="./test_result/debug.log"

#usage(){
# echo "Usage: `basename $0` startNum stopNum"
#}

#从流媒体进行录像
recordStream(){
# mkdir -p /cVideo/cStor/cVideo/record/$1
#base_path="/var/share/Default/doc/NAS_EC/32/"
#current_date=`date +%Y_%m_%d`
#expect_dir=${base_path}${current_date}

#if [ ! -d ${expect_dir} ];then
#    mkdir -p ${expect_dir}
#fi
#/usr/bin/ffmpeg -loglevel quiet -i rtmp://127.0.0.1:1554/live/cam$1 -c copy -f segment -segment_atclocktime 0 -reset_timestamps 1 -segment_time 1800 -segment_format mp4 ${expect_dir}/cam$1_`date "+%Y-%m-%d_%H:%M"`_%d.mp4 &

/usr/bin/ffmpeg -loglevel quiet -i rtmp://127.0.0.1:1554/live/cam$1 -c copy -f segment -segment_atclocktime 0 -reset_timestamps 1 -segment_time $3 -segment_format mp4 $2/cam$1_`date "+%Y-%m-%d_%H:%M"`_%d.mp4 &
echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tStart recording process $1  PID: $!\n" | tee -a $DEBUG_LOG
}


#if [ $# -lt 2 ];then
# usage
# exit 1
#fi


numStartRtmp=$1
numStopRtmp=$2

for((i=$numStartRtmp;i<=$numStopRtmp;i++))
do
if [ `expr $i % 100` = 0 ];then
  sleep 1
 fi

 {
  recordStream $i $3 $4
 } 

done
