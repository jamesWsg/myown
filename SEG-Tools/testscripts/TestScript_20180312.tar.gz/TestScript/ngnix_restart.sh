/etc/init.d/nginx restart
echo -e "---------------------------------"
bash monitor.sh
