#!/bin/bash


getStreamMonitor(){
num=`ps -ef |grep ffmpeg |grep -v grep |grep rtsp |wc -l`
echo "getStream num: $num"
}

pushStreamMonitor(){
num=`ps -ef |grep ffmpeg |grep -v grep |grep -v rtsp|grep flv |wc -l`
echo "pushStream num: $num"
}

recordStreamMonitor(){
num=`ps -ef |grep ffmpeg |grep -v grep |grep -v rtsp|grep segment|wc -l`
echo "recordStream num: $num"
}

getStreamMonitor
pushStreamMonitor
recordStreamMonitor

exit 0;
