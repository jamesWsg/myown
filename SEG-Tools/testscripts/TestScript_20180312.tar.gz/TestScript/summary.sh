#!/bin/bash

#####################################
# $1: stream data folder
#####################################

DEBUG_LOG="./test_result/debug.log"

# Check stream data size
tmp_file_size=0
for file in `ls --sort=time --time=ctime $1`
do
	file_size=`du -b $1/$file | awk '{print $1}'`
	if [ $tmp_file_size != 0 ];then
		if [ $file_size != $tmp_file_size ];then
			echo -e "`date +'%Y-%m-%d %H:%M:%N'`\tStream size is abnormal!! Suspect is: $1/$file; Size is: $file_size." | tee -a $DEBUG_LOG
			continue
		fi
	fi
	tmp_file_size=$file_size
done


