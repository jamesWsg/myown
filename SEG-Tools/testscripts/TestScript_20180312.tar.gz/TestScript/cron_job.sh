#!/bin/bash

START_SCRIPT=/root/cVideo_v3.0.3/TestScript/run_all.sh

/etc/init.d/nginx restart

while 1;
do
	cnt=`ps -ef | grep ffpmeg | grep -v grep | wc -l`
	if [ $cnt -eq 0 ];then
		break	
	fi
	sleep 2
done

$START_SCRIPT /var/share/Default/doc/NAS_EC/33/ 1800 100 
